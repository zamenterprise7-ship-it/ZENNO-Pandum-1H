package com.zenno.pandum;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends Activity {
    private LinearLayout root;
    private LinearLayout appList;
    private boolean showingApps = false;
    private final int navy = Color.rgb(13, 25, 45);
    private final int blue = Color.rgb(55, 135, 225);
    private final int gold = Color.rgb(218, 176, 83);

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        showHome();
    }

    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        return t;
    }

    private void setup(String title) {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(22, 28, 22, 18);
        root.setBackgroundColor(navy);
        setContentView(root);
        TextView heading = text(title, 26, Color.WHITE);
        heading.setTypeface(null, Typeface.BOLD);
        heading.setGravity(Gravity.CENTER);
        root.addView(heading, new LinearLayout.LayoutParams(-1, 70));
        TextView sub = text("Pandum 1H  •  Sukoon Wali Roshni", 12, gold);
        sub.setGravity(Gravity.CENTER);
        root.addView(sub, new LinearLayout.LayoutParams(-1, 30));
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(blue));
        return b;
    }

    private void showHome() {
        showingApps = false;
        setup("ZENNO");
        TextView welcome = text("Your phone. Your calm space.", 16, Color.LTGRAY);
        welcome.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams wp = new LinearLayout.LayoutParams(-1, 0, 1);
        root.addView(welcome, wp);

        Button camera = button("OPEN CAMERA");
        camera.setOnClickListener(v -> launchFirst(new String[]{"com.mediatek.camera", "com.android.camera2", "com.android.camera"}));
        root.addView(camera, new LinearLayout.LayoutParams(-1, 58));

        Button whatsapp = button("OPEN WHATSAPP");
        whatsapp.setOnClickListener(v -> launchFirst(new String[]{"com.whatsapp"}));
        root.addView(whatsapp, new LinearLayout.LayoutParams(-1, 58));

        Button apps = button("ALL APPS");
        apps.setOnClickListener(v -> showApps());
        root.addView(apps, new LinearLayout.LayoutParams(-1, 58));

        TextView footer = text("ZENNO Pandum 1H", 12, gold);
        footer.setGravity(Gravity.CENTER);
        root.addView(footer, new LinearLayout.LayoutParams(-1, 50));
    }

    private void launchFirst(String[] packages) {
        for (String pkg : packages) {
            Intent i = getPackageManager().getLaunchIntentForPackage(pkg);
            if (i != null) { startActivity(i); return; }
        }
        Toast.makeText(this, "App not found on this phone", Toast.LENGTH_SHORT).show();
    }

    private void showApps() {
        showingApps = true;
        setup("ALL APPS");
        ScrollView scroll = new ScrollView(this);
        appList = new LinearLayout(this);
        appList.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(appList);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        Intent query = new Intent(Intent.ACTION_MAIN, null);
        query.addCategory(Intent.CATEGORY_LAUNCHER);
        PackageManager pm = getPackageManager();
        List<ResolveInfo> apps = pm.queryIntentActivities(query, 0);
        Collections.sort(apps, new Comparator<ResolveInfo>() {
            public int compare(ResolveInfo a, ResolveInfo b) {
                return a.loadLabel(pm).toString().compareToIgnoreCase(b.loadLabel(pm).toString());
            }
        });
        for (ResolveInfo info : apps) {
            String pkg = info.activityInfo.packageName;
            TextView item = text("•  " + info.loadLabel(pm), 17, Color.WHITE);
            item.setPadding(12, 14, 12, 14);
            item.setOnClickListener(v -> {
                Intent launch = pm.getLaunchIntentForPackage(pkg);
                if (launch != null) startActivity(launch);
            });
            appList.addView(item);
            View line = new View(this); line.setBackgroundColor(0xff34445a);
            appList.addView(line, new LinearLayout.LayoutParams(-1, 1));
        }
        Button back = button("HOME");
        back.setOnClickListener(v -> showHome());
        root.addView(back, new LinearLayout.LayoutParams(-1, 54));
    }

    @Override public void onBackPressed() {
        if (showingApps) showHome(); else super.onBackPressed();
    }
}
