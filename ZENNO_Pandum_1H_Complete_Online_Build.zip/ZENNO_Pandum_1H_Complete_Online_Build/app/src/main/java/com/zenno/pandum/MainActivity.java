
package com.zenno.pandum;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {

    private LinearLayout root;
    private boolean showingApps = false;
    private final int navy = 0xff14243d;
    private final int blue = 0xff579ce8;
    private final int gold = 0xffd9b45c;
    private final int white = 0xffffffff;
    private final int pale = 0xffedf5ff;
    private Handler handler = new Handler();

    private Runnable clockUpdate = new Runnable() {
        @Override
        public void run() {
            TextView clock = findViewById(1001);
            TextView date = findViewById(1002);
            if (clock != null) {
                clock.setText(new SimpleDateFormat(
                    "hh:mm", Locale.getDefault()).format(new Date()));
            }
            if (date != null) {
                date.setText(new SimpleDateFormat(
                    "EEEE, dd MMMM", Locale.getDefault()).format(new Date()));
            }
            handler.postDelayed(this, 1000);
        }
    };

    @Override
    public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setStatusBarColor(pale);
        getWindow().setNavigationBarColor(white);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR |
            View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        );
        showHome();
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        return d;
    }

    private TextView text(String value, int size, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout horizontal() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER);
        return l;
    }

    private TextView centered(String value, int size, int color) {
        TextView t = text(value, size, color);
        t.setGravity(Gravity.CENTER);
        return t;
    }

    private void showHome() {
        showingApps = false;
        handler.removeCallbacks(clockUpdate);

        root = vertical();
        root.setPadding(22, 18, 22, 14);
        root.setBackgroundColor(pale);
        setContentView(root);

        LinearLayout top = horizontal();
        TextView logo = text("Z", 27, blue);
        logo.setTypeface(null, Typeface.BOLD);
        top.addView(logo);

        LinearLayout brand = vertical();
        TextView name = text("ZENNO", 20, navy);
        name.setTypeface(null, Typeface.BOLD);
        brand.addView(name);
        brand.addView(text("PANDUM 1H", 10, gold));
        top.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));

        TextView menu = centered("•••", 23, navy);
        top.addView(menu, new LinearLayout.LayoutParams(45, 45));
        root.addView(top);

        TextView clock = centered("09:45", 58, navy);
        clock.setId(1001);
        clock.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams cp =
            new LinearLayout.LayoutParams(-1, 90);
        cp.topMargin = 38;
        root.addView(clock, cp);

        TextView date = centered("Monday, 10 November", 15, blue);
        date.setId(1002);
        root.addView(date);
        handler.post(clockUpdate);

        TextView greeting = centered(
            "Sukoon Wali Roshni", 15, gold);
        LinearLayout.LayoutParams gp =
            new LinearLayout.LayoutParams(-1, 45);
        gp.topMargin = 12;
        root.addView(greeting, gp);

        TextView section = text("YOUR FAVOURITES", 12, navy);
        section.setTypeface(null, Typeface.BOLD);
        LinearLayout.LayoutParams sp =
            new LinearLayout.LayoutParams(-1, 35);
        sp.topMargin = 22;
        root.addView(section, sp);

        LinearLayout row1 = horizontal();
        addShortcut(row1, "📷", "Camera",
            new String[]{"com.mediatek.camera"});
        addShortcut(row1, "💬", "WhatsApp",
            new String[]{"com.whatsapp"});
        addShortcut(row1, "🌐", "Chrome",
            new String[]{"com.android.chrome"});
        root.addView(row1);

        LinearLayout row2 = horizontal();
        addShortcut(row2, "▶️", "YouTube",
            new String[]{"com.google.android.youtube"});
        addShortcut(row2, "🛍️", "Play Store",
            new String[]{"com.android.vending"});
        addShortcut(row2, "📁", "Files",
            new String[]{"com.google.android.apps.nbu.files"});
        root.addView(row2);

        View space = new View(this);
        root.addView(space, new LinearLayout.LayoutParams(1, 0, 1));

        LinearLayout dock = horizontal();
        dock.setPadding(8, 8, 8, 8);
        dock.setBackground(shape(white, 35));

        addDock(dock, "☎", "Phone",
            new String[]{"com.android.dialer"});
        addDock(dock, "✉", "Messages",
            new String[]{"com.google.android.apps.messaging"});
        addDock(dock, "👥", "Contacts",
            new String[]{"com.android.contacts"});
        addDock(dock, "▦", "Apps",
            null);

        root.addView(dock,
            new LinearLayout.LayoutParams(-1, 76));

        TextView footer = centered(
            "ZENNO  •  Powered by Android", 10, blue);
        root.addView(footer,
            new LinearLayout.LayoutParams(-1, 30));
    }

    private void addShortcut(LinearLayout row,
                             String icon, String label,
                             String[] packages) {
        LinearLayout cell = vertical();
        cell.setGravity(Gravity.CENTER);
        cell.setPadding(4, 12, 4, 12);
        cell.setBackground(shape(white, 22));

        TextView symbol = centered(icon, 29, navy);
        cell.addView(symbol,
            new LinearLayout.LayoutParams(-1, 48));

        cell.addView(centered(label, 11, navy));

        cell.setOnClickListener(v -> launchFirst(packages));

        LinearLayout.LayoutParams p =
            new LinearLayout.LayoutParams(0, 90, 1);
        p.setMargins(4, 5, 4, 5);
        row.addView(cell, p);
    }

    private void addDock(LinearLayout dock,
                         String icon, String label,
                         String[] packages) {
        LinearLayout cell = vertical();
        cell.setGravity(Gravity.CENTER);

        cell.addView(centered(icon, 25, blue));
        cell.addView(centered(label, 10, navy));

        cell.setOnClickListener(v -> {
            if (packages == null) showApps();
            else launchFirst(packages);
        });

        dock.addView(cell,
            new LinearLayout.LayoutParams(0, 58, 1));
    }

    private void launchFirst(String[] packages) {
        if (packages == null) return;

        for (String pkg : packages) {
            Intent i = getPackageManager()
                .getLaunchIntentForPackage(pkg);
            if (i != null) {
                startActivity(i);
                return;
            }
        }

        Toast.makeText(this, "App not found",
            Toast.LENGTH_SHORT).show();
    }

    private void showApps() {
        showingApps = true;
        handler.removeCallbacks(clockUpdate);

        root = vertical();
        root.setPadding(18, 20, 18, 12);
        root.setBackgroundColor(pale);
        setContentView(root);

        TextView heading = text("APPS", 27, navy);
        heading.setTypeface(null, Typeface.BOLD);
        root.addView(heading);

        root.addView(text("Your applications", 13, blue));

        ScrollView scroll = new ScrollView(this);
        LinearLayout list = vertical();
        scroll.addView(list);

        Intent query = new Intent(Intent.ACTION_MAIN, null);
        query.addCategory(Intent.CATEGORY_LAUNCHER);

        PackageManager pm = getPackageManager();
        List<ResolveInfo> apps =
            pm.queryIntentActivities(query, 0);

        Collections.sort(apps, (a, b) ->
            a.loadLabel(pm).toString()
                .compareToIgnoreCase(
                    b.loadLabel(pm).toString()));

        LinearLayout row = null;
        int count = 0;

        for (ResolveInfo info : apps) {
            if (count % 3 == 0) {
                row = horizontal();
                list.addView(row);
            }

            final String pkg = info.activityInfo.packageName;

            LinearLayout cell = vertical();
            cell.setGravity(Gravity.CENTER);
            cell.setPadding(4, 12, 4, 12);
            cell.setBackground(shape(white, 20));

            ImageView icon = new ImageView(this);
            try {
                icon.setImageDrawable(info.loadIcon(pm));
            } catch (Exception ignored) {}

            cell.addView(icon,
                new LinearLayout.LayoutParams(43, 43));

            TextView label = centered(
                info.loadLabel(pm).toString(), 11, navy);
            label.setMaxLines(2);
            cell.addView(label);

            cell.setOnClickListener(v -> {
                Intent launch =
                    pm.getLaunchIntentForPackage(pkg);
                if (launch != null) startActivity(launch);
            });

            LinearLayout.LayoutParams p =
                new LinearLayout.LayoutParams(0, 95, 1);
            p.setMargins(4, 5, 4, 5);
            row.addView(cell, p);
            count++;
        }

        root.addView(scroll,
            new LinearLayout.LayoutParams(-1, 0, 1));

        Button home = new Button(this);
        home.setText("HOME");
        home.setTextColor(white);
        home.setBackgroundTintList(
            android.content.res.ColorStateList.valueOf(blue));
        home.setOnClickListener(v -> showHome());
        root.addView(home);
    }

    @Override
    public void onBackPressed() {
        if (showingApps) showHome();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(clockUpdate);
        super.onDestroy();
    }
}
